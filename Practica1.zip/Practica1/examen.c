#include<stdio.h>
int 5;
float 0.6;
"hola mundo";
return 0;